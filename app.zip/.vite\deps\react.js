import {
  require_react
} from "./chunk-REFQX4J5.js";
export default require_react();
//# sourceMappingURL=react.js.map
