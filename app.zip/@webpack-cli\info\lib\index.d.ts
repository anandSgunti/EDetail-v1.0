import { type IWebpackCLI } from "webpack-cli";
declare class InfoCommand {
    apply(cli: IWebpackCLI): Promise<void>;
}
export default InfoCommand;
